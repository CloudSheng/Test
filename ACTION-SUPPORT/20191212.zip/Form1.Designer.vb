﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意:  以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.成品批次特采ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SN批次报废ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.每日盘点设置ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.客制工站完工报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.客制订单报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.客制返工报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.客制隔离待判报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.客制报废报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.生管用完工报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.经过次数报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.经过次数报表ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.客制交接报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.WIP报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.客制盘点报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.财务用盘点报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WIP分站存量报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.涂装WIP报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WIP库龄报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.胶合WIP报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.接收站库龄表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.成品库龄报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.客制报废日报表ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.产品静置时间表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.返修记录报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MES基础资料报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MES样品进度报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MES报废月报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.客制报废解锁报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.生管用过程缺陷报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MESToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MachineDefectReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.產品直通率週報ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QC称重客制报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.客制移站报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.批号SN明细表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.样品报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SN库龄表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ERPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.出纳ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.集团资金预估表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.东莞物料需求AP模拟ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.模具AP报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WorkingCapitalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.银行存款余额调节表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.資金計畫表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.資金計畫表匯入入庫計劃ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.生管ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.出货金额及入库金额ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.模拟展料报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.模拟展料报表全部料件ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.未结案工单明细ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.主材料损耗率报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.不良品库存与返工工单匹配表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.请购单汇入ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.资材ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.单阶材料用途表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.材料用途查询ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.杂发单ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.排程ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.排程汇入ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.胶合周排程用量表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.材料用途报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShipmentManagementToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.入库计划汇入ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ERP安全存量汇入ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DemandAndScheduleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MPL接单记录ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.原材料进料计划达成汇总报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.采购ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.客制询价次数报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.客制采购年度报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.客制询价明细报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.付款期报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.客制采购月度报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.采购成本指标ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.验退仓退明细表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.采购入库金额单价采购量统计表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.技术ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.专案报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.专案人力输入ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.专案工时报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RD纱料用量表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RD人工工时月报ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tooling完工比例报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.成本ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.报废报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.客户别销售WIP库存成本ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.工单用量分析表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.成本变动表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.采购及委外成本变动表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.采购委外料件杂收发明细表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BOM表物料标准成本与实际成本明细表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.工单上阶在制成本明细表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.标准成本变动表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.标准成本明细表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.工单下阶在制成本明细表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.库龄成本分析ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.标准采购单价与实际采购单价比较表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.品质报废周报金额统计表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.部门杂收发表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.成本倒扎表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.审计倒扎表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DAC销售成本毛利资料报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.核查ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.杂收与库存对照表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ERP入库与MES移转查核ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ERP工单套数表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.销售ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HACToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DAC月销售报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DAC最后单价ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HAC销售日报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HAC销售周报ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HACToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesCompareWithBudgetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PWC产品分析明细表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应收ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HACAR账龄报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DACAR账龄报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ACAAR账龄报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HACAR账龄报表ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DACAR账龄报表ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ACA账龄报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BVIAR账龄报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DACInvoice单价分析报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.應收帳款预测表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应付ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.年度应付报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.东莞应付帐龄表ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.预算ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.销售费用统计表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.制造费用表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.研发费用表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.管理费用表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DAC客户价格比价ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.毛利分析表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.项目案预算比较表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.客户预ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.部门费用表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RollingForecastToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.部门费用及预算汇总表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.功能主管费用表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DAC销售预算报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DACToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.主要物料进料需求表购料资金ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.工时变更汇入ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.总工时重计ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.周生产资源计划报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.多交期汇入ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ForecastToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TrainfreightSIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SeafreightSIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.产品EOP时间批次更新ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VDALabel列印资料ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.待结案料号明细表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FinicialReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountingReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.客诉费用统计表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.空运费用统计表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.总账ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ISToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CashFlowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CashFlowForeCastToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.外币余额表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.传票汇入ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.每周费用汇总报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ACAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.运费汇入ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.运费明细表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.损益表汇入ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ACAISToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.资产负债表汇入ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ACABSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CallOff汇入ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FIFO计算ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.关务ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.出口货物报关单ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.进口手册报关单ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.进口贸易报关单ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.工务ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.关键零部件报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HACToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.汇入VACARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.产ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MES型号站别与ERP料号对应表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MES与ERP数量比对表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.顾客PN检查报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MES连线测试ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ERP连线测试ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.版本资讯ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.搬家ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TESTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.计算机ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TEST2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InventoryCountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.离开系统ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.成型模具使用次数ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.MESToolStripMenuItem, Me.ToolStripMenuItem5, Me.ERPToolStripMenuItem, Me.ToolStripMenuItem3, Me.ToolStripMenuItem2, Me.离开系统ToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(4, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(950, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.成品批次特采ToolStripMenuItem, Me.SN批次报废ToolStripMenuItem, Me.每日盘点设置ToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(69, 20)
        Me.ToolStripMenuItem1.Text = "MES系统"
        '
        '成品批次特采ToolStripMenuItem
        '
        Me.成品批次特采ToolStripMenuItem.Enabled = False
        Me.成品批次特采ToolStripMenuItem.Name = "成品批次特采ToolStripMenuItem"
        Me.成品批次特采ToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.成品批次特采ToolStripMenuItem.Text = "成品批次特采"
        '
        'SN批次报废ToolStripMenuItem
        '
        Me.SN批次报废ToolStripMenuItem.Enabled = False
        Me.SN批次报废ToolStripMenuItem.Name = "SN批次报废ToolStripMenuItem"
        Me.SN批次报废ToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.SN批次报废ToolStripMenuItem.Text = "SN批次报废"
        '
        '每日盘点设置ToolStripMenuItem
        '
        Me.每日盘点设置ToolStripMenuItem.Name = "每日盘点设置ToolStripMenuItem"
        Me.每日盘点设置ToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.每日盘点设置ToolStripMenuItem.Text = "每日盘点设置"
        '
        'MESToolStripMenuItem
        '
        Me.MESToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.客制工站完工报表ToolStripMenuItem, Me.客制订单报表ToolStripMenuItem, Me.客制返工报表ToolStripMenuItem, Me.客制隔离待判报表ToolStripMenuItem, Me.客制报废报表ToolStripMenuItem, Me.生管用完工报表ToolStripMenuItem, Me.经过次数报表ToolStripMenuItem, Me.客制交接报表ToolStripMenuItem, Me.ToolStripMenuItem7, Me.WIP报表ToolStripMenuItem, Me.客制报废日报表ToolStripMenuItem1, Me.产品静置时间表ToolStripMenuItem, Me.返修记录报表ToolStripMenuItem, Me.MES基础资料报表ToolStripMenuItem, Me.MES样品进度报表ToolStripMenuItem, Me.MES报废月报表ToolStripMenuItem, Me.ToolStripMenuItem6, Me.客制报废解锁报表ToolStripMenuItem, Me.生管用过程缺陷报表ToolStripMenuItem, Me.MESToolStripMenuItem1, Me.MachineDefectReportToolStripMenuItem, Me.產品直通率週報ToolStripMenuItem, Me.QC称重客制报表ToolStripMenuItem, Me.客制移站报表ToolStripMenuItem, Me.成型模具使用次数ToolStripMenuItem})
        Me.MESToolStripMenuItem.Name = "MESToolStripMenuItem"
        Me.MESToolStripMenuItem.Size = New System.Drawing.Size(69, 20)
        Me.MESToolStripMenuItem.Text = "MES报表"
        '
        '客制工站完工报表ToolStripMenuItem
        '
        Me.客制工站完工报表ToolStripMenuItem.Name = "客制工站完工报表ToolStripMenuItem"
        Me.客制工站完工报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.客制工站完工报表ToolStripMenuItem.Text = "客制工站完工报表"
        '
        '客制订单报表ToolStripMenuItem
        '
        Me.客制订单报表ToolStripMenuItem.Name = "客制订单报表ToolStripMenuItem"
        Me.客制订单报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.客制订单报表ToolStripMenuItem.Text = "裁纱ERP工单与MES制令汇总对比报表"
        '
        '客制返工报表ToolStripMenuItem
        '
        Me.客制返工报表ToolStripMenuItem.Name = "客制返工报表ToolStripMenuItem"
        Me.客制返工报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.客制返工报表ToolStripMenuItem.Text = "客制返工报表"
        '
        '客制隔离待判报表ToolStripMenuItem
        '
        Me.客制隔离待判报表ToolStripMenuItem.Name = "客制隔离待判报表ToolStripMenuItem"
        Me.客制隔离待判报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.客制隔离待判报表ToolStripMenuItem.Text = "客制隔离待判报表"
        '
        '客制报废报表ToolStripMenuItem
        '
        Me.客制报废报表ToolStripMenuItem.Name = "客制报废报表ToolStripMenuItem"
        Me.客制报废报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.客制报废报表ToolStripMenuItem.Text = "0330客制报废报表"
        '
        '生管用完工报表ToolStripMenuItem
        '
        Me.生管用完工报表ToolStripMenuItem.Name = "生管用完工报表ToolStripMenuItem"
        Me.生管用完工报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.生管用完工报表ToolStripMenuItem.Text = "生产计划完工报表"
        '
        '经过次数报表ToolStripMenuItem
        '
        Me.经过次数报表ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.经过次数报表ToolStripMenuItem1})
        Me.经过次数报表ToolStripMenuItem.Name = "经过次数报表ToolStripMenuItem"
        Me.经过次数报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.经过次数报表ToolStripMenuItem.Text = "0590经过次数报表"
        '
        '经过次数报表ToolStripMenuItem1
        '
        Me.经过次数报表ToolStripMenuItem1.Name = "经过次数报表ToolStripMenuItem1"
        Me.经过次数报表ToolStripMenuItem1.Size = New System.Drawing.Size(174, 22)
        Me.经过次数报表ToolStripMenuItem1.Text = "0590经过次数报表"
        '
        '客制交接报表ToolStripMenuItem
        '
        Me.客制交接报表ToolStripMenuItem.Name = "客制交接报表ToolStripMenuItem"
        Me.客制交接报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.客制交接报表ToolStripMenuItem.Text = "客制交接报表"
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(278, 22)
        Me.ToolStripMenuItem7.Text = "配件交接报表"
        '
        'WIP报表ToolStripMenuItem
        '
        Me.WIP报表ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.客制盘点报表ToolStripMenuItem, Me.财务用盘点报表ToolStripMenuItem, Me.WIP分站存量报表ToolStripMenuItem, Me.涂装WIP报表ToolStripMenuItem, Me.WIP库龄报表ToolStripMenuItem, Me.胶合WIP报表ToolStripMenuItem, Me.接收站库龄表ToolStripMenuItem, Me.成品库龄报表ToolStripMenuItem})
        Me.WIP报表ToolStripMenuItem.Name = "WIP报表ToolStripMenuItem"
        Me.WIP报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.WIP报表ToolStripMenuItem.Text = "WIP报表"
        '
        '客制盘点报表ToolStripMenuItem
        '
        Me.客制盘点报表ToolStripMenuItem.Name = "客制盘点报表ToolStripMenuItem"
        Me.客制盘点报表ToolStripMenuItem.Size = New System.Drawing.Size(273, 22)
        Me.客制盘点报表ToolStripMenuItem.Text = "WIP工段进度表(排程-通用流程分类）"
        '
        '财务用盘点报表ToolStripMenuItem
        '
        Me.财务用盘点报表ToolStripMenuItem.Name = "财务用盘点报表ToolStripMenuItem"
        Me.财务用盘点报表ToolStripMenuItem.Size = New System.Drawing.Size(273, 22)
        Me.财务用盘点报表ToolStripMenuItem.Text = "财务用盘点报表"
        '
        'WIP分站存量报表ToolStripMenuItem
        '
        Me.WIP分站存量报表ToolStripMenuItem.Name = "WIP分站存量报表ToolStripMenuItem"
        Me.WIP分站存量报表ToolStripMenuItem.Size = New System.Drawing.Size(273, 22)
        Me.WIP分站存量报表ToolStripMenuItem.Text = "WIP分站存量报表"
        '
        '涂装WIP报表ToolStripMenuItem
        '
        Me.涂装WIP报表ToolStripMenuItem.Name = "涂装WIP报表ToolStripMenuItem"
        Me.涂装WIP报表ToolStripMenuItem.Size = New System.Drawing.Size(273, 22)
        Me.涂装WIP报表ToolStripMenuItem.Text = "涂装WIP报表"
        '
        'WIP库龄报表ToolStripMenuItem
        '
        Me.WIP库龄报表ToolStripMenuItem.Name = "WIP库龄报表ToolStripMenuItem"
        Me.WIP库龄报表ToolStripMenuItem.Size = New System.Drawing.Size(273, 22)
        Me.WIP库龄报表ToolStripMenuItem.Text = "WIP库龄报表"
        '
        '胶合WIP报表ToolStripMenuItem
        '
        Me.胶合WIP报表ToolStripMenuItem.Name = "胶合WIP报表ToolStripMenuItem"
        Me.胶合WIP报表ToolStripMenuItem.Size = New System.Drawing.Size(273, 22)
        Me.胶合WIP报表ToolStripMenuItem.Text = "胶合WIP报表"
        '
        '接收站库龄表ToolStripMenuItem
        '
        Me.接收站库龄表ToolStripMenuItem.Name = "接收站库龄表ToolStripMenuItem"
        Me.接收站库龄表ToolStripMenuItem.Size = New System.Drawing.Size(273, 22)
        Me.接收站库龄表ToolStripMenuItem.Text = "接收站库龄表"
        '
        '成品库龄报表ToolStripMenuItem
        '
        Me.成品库龄报表ToolStripMenuItem.Name = "成品库龄报表ToolStripMenuItem"
        Me.成品库龄报表ToolStripMenuItem.Size = New System.Drawing.Size(273, 22)
        Me.成品库龄报表ToolStripMenuItem.Text = "成品库龄报表"
        '
        '客制报废日报表ToolStripMenuItem1
        '
        Me.客制报废日报表ToolStripMenuItem1.Name = "客制报废日报表ToolStripMenuItem1"
        Me.客制报废日报表ToolStripMenuItem1.Size = New System.Drawing.Size(278, 22)
        Me.客制报废日报表ToolStripMenuItem1.Text = "客制报废日报表"
        '
        '产品静置时间表ToolStripMenuItem
        '
        Me.产品静置时间表ToolStripMenuItem.Name = "产品静置时间表ToolStripMenuItem"
        Me.产品静置时间表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.产品静置时间表ToolStripMenuItem.Text = "产品静置时间表"
        '
        '返修记录报表ToolStripMenuItem
        '
        Me.返修记录报表ToolStripMenuItem.Name = "返修记录报表ToolStripMenuItem"
        Me.返修记录报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.返修记录报表ToolStripMenuItem.Text = "返修记录报表"
        '
        'MES基础资料报表ToolStripMenuItem
        '
        Me.MES基础资料报表ToolStripMenuItem.Name = "MES基础资料报表ToolStripMenuItem"
        Me.MES基础资料报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.MES基础资料报表ToolStripMenuItem.Text = "MES基础资料报表"
        '
        'MES样品进度报表ToolStripMenuItem
        '
        Me.MES样品进度报表ToolStripMenuItem.Name = "MES样品进度报表ToolStripMenuItem"
        Me.MES样品进度报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.MES样品进度报表ToolStripMenuItem.Text = "MES样品进度报表"
        '
        'MES报废月报表ToolStripMenuItem
        '
        Me.MES报废月报表ToolStripMenuItem.Name = "MES报废月报表ToolStripMenuItem"
        Me.MES报废月报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.MES报废月报表ToolStripMenuItem.Text = "MES报废月报表"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(278, 22)
        Me.ToolStripMenuItem6.Text = "MES接收工站与ERP入库数量比对報表"
        '
        '客制报废解锁报表ToolStripMenuItem
        '
        Me.客制报废解锁报表ToolStripMenuItem.Name = "客制报废解锁报表ToolStripMenuItem"
        Me.客制报废解锁报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.客制报废解锁报表ToolStripMenuItem.Text = "客制报废解锁报表"
        '
        '生管用过程缺陷报表ToolStripMenuItem
        '
        Me.生管用过程缺陷报表ToolStripMenuItem.Name = "生管用过程缺陷报表ToolStripMenuItem"
        Me.生管用过程缺陷报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.生管用过程缺陷报表ToolStripMenuItem.Text = "生管用过程缺陷报表"
        '
        'MESToolStripMenuItem1
        '
        Me.MESToolStripMenuItem1.Name = "MESToolStripMenuItem1"
        Me.MESToolStripMenuItem1.Size = New System.Drawing.Size(278, 22)
        Me.MESToolStripMenuItem1.Text = "MES重印标签明细表"
        '
        'MachineDefectReportToolStripMenuItem
        '
        Me.MachineDefectReportToolStripMenuItem.Name = "MachineDefectReportToolStripMenuItem"
        Me.MachineDefectReportToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.MachineDefectReportToolStripMenuItem.Text = "Machine Defect Report"
        '
        '產品直通率週報ToolStripMenuItem
        '
        Me.產品直通率週報ToolStripMenuItem.Name = "產品直通率週報ToolStripMenuItem"
        Me.產品直通率週報ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.產品直通率週報ToolStripMenuItem.Text = "產品直通率週報"
        '
        'QC称重客制报表ToolStripMenuItem
        '
        Me.QC称重客制报表ToolStripMenuItem.Name = "QC称重客制报表ToolStripMenuItem"
        Me.QC称重客制报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.QC称重客制报表ToolStripMenuItem.Text = "QC称重客制报表"
        '
        '客制移站报表ToolStripMenuItem
        '
        Me.客制移站报表ToolStripMenuItem.Name = "客制移站报表ToolStripMenuItem"
        Me.客制移站报表ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.客制移站报表ToolStripMenuItem.Text = "客制移站报表"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.批号SN明细表ToolStripMenuItem, Me.样品报表ToolStripMenuItem, Me.SN库龄表ToolStripMenuItem})
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(65, 20)
        Me.ToolStripMenuItem5.Text = "RD MES"
        '
        '批号SN明细表ToolStripMenuItem
        '
        Me.批号SN明细表ToolStripMenuItem.Name = "批号SN明细表ToolStripMenuItem"
        Me.批号SN明细表ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.批号SN明细表ToolStripMenuItem.Text = "批号SN明细表"
        '
        '样品报表ToolStripMenuItem
        '
        Me.样品报表ToolStripMenuItem.Name = "样品报表ToolStripMenuItem"
        Me.样品报表ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.样品报表ToolStripMenuItem.Text = "样品报表"
        '
        'SN库龄表ToolStripMenuItem
        '
        Me.SN库龄表ToolStripMenuItem.Name = "SN库龄表ToolStripMenuItem"
        Me.SN库龄表ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.SN库龄表ToolStripMenuItem.Text = "SN库龄表"
        '
        'ERPToolStripMenuItem
        '
        Me.ERPToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.出纳ToolStripMenuItem, Me.生管ToolStripMenuItem, Me.采购ToolStripMenuItem, Me.技术ToolStripMenuItem, Me.成本ToolStripMenuItem, Me.核查ToolStripMenuItem, Me.销售ToolStripMenuItem, Me.应收ToolStripMenuItem, Me.应付ToolStripMenuItem, Me.预算ToolStripMenuItem, Me.IEToolStripMenuItem, Me.PMToolStripMenuItem, Me.MDToolStripMenuItem, Me.总账ToolStripMenuItem, Me.ACAToolStripMenuItem, Me.关务ToolStripMenuItem, Me.工务ToolStripMenuItem, Me.HACToolStripMenuItem2})
        Me.ERPToolStripMenuItem.Name = "ERPToolStripMenuItem"
        Me.ERPToolStripMenuItem.Size = New System.Drawing.Size(65, 20)
        Me.ERPToolStripMenuItem.Text = "ERP报表"
        '
        '出纳ToolStripMenuItem
        '
        Me.出纳ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.集团资金预估表ToolStripMenuItem, Me.东莞物料需求AP模拟ToolStripMenuItem, Me.模具AP报表ToolStripMenuItem, Me.WorkingCapitalToolStripMenuItem, Me.银行存款余额调节表ToolStripMenuItem, Me.資金計畫表ToolStripMenuItem, Me.資金計畫表匯入入庫計劃ToolStripMenuItem})
        Me.出纳ToolStripMenuItem.Name = "出纳ToolStripMenuItem"
        Me.出纳ToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.出纳ToolStripMenuItem.Text = "出纳"
        '
        '集团资金预估表ToolStripMenuItem
        '
        Me.集团资金预估表ToolStripMenuItem.Name = "集团资金预估表ToolStripMenuItem"
        Me.集团资金预估表ToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.集团资金预估表ToolStripMenuItem.Text = "集团资金预估表"
        '
        '东莞物料需求AP模拟ToolStripMenuItem
        '
        Me.东莞物料需求AP模拟ToolStripMenuItem.Name = "东莞物料需求AP模拟ToolStripMenuItem"
        Me.东莞物料需求AP模拟ToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.东莞物料需求AP模拟ToolStripMenuItem.Text = "东莞物料需求AP模拟"
        '
        '模具AP报表ToolStripMenuItem
        '
        Me.模具AP报表ToolStripMenuItem.Name = "模具AP报表ToolStripMenuItem"
        Me.模具AP报表ToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.模具AP报表ToolStripMenuItem.Text = "未采购模具AP报表"
        '
        'WorkingCapitalToolStripMenuItem
        '
        Me.WorkingCapitalToolStripMenuItem.Name = "WorkingCapitalToolStripMenuItem"
        Me.WorkingCapitalToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.WorkingCapitalToolStripMenuItem.Text = "Working Capital"
        '
        '银行存款余额调节表ToolStripMenuItem
        '
        Me.银行存款余额调节表ToolStripMenuItem.Name = "银行存款余额调节表ToolStripMenuItem"
        Me.银行存款余额调节表ToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.银行存款余额调节表ToolStripMenuItem.Text = "银行存款余额调节表"
        '
        '資金計畫表ToolStripMenuItem
        '
        Me.資金計畫表ToolStripMenuItem.Name = "資金計畫表ToolStripMenuItem"
        Me.資金計畫表ToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.資金計畫表ToolStripMenuItem.Text = "資金計畫表"
        '
        '資金計畫表匯入入庫計劃ToolStripMenuItem
        '
        Me.資金計畫表匯入入庫計劃ToolStripMenuItem.Name = "資金計畫表匯入入庫計劃ToolStripMenuItem"
        Me.資金計畫表匯入入庫計劃ToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.資金計畫表匯入入庫計劃ToolStripMenuItem.Text = "資金計畫表-匯入入庫計劃"
        '
        '生管ToolStripMenuItem
        '
        Me.生管ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.出货金额及入库金额ToolStripMenuItem, Me.模拟展料报表ToolStripMenuItem, Me.模拟展料报表全部料件ToolStripMenuItem, Me.未结案工单明细ToolStripMenuItem, Me.主材料损耗率报表ToolStripMenuItem, Me.不良品库存与返工工单匹配表ToolStripMenuItem, Me.请购单汇入ToolStripMenuItem, Me.资材ToolStripMenuItem, Me.单阶材料用途表ToolStripMenuItem, Me.材料用途查询ToolStripMenuItem, Me.杂发单ToolStripMenuItem, Me.排程ToolStripMenuItem, Me.材料用途报表ToolStripMenuItem, Me.ShipmentManagementToolStripMenuItem, Me.入库计划汇入ToolStripMenuItem, Me.ERP安全存量汇入ToolStripMenuItem, Me.DemandAndScheduleToolStripMenuItem, Me.MPL接单记录ToolStripMenuItem, Me.原材料进料计划达成汇总报表ToolStripMenuItem})
        Me.生管ToolStripMenuItem.Name = "生管ToolStripMenuItem"
        Me.生管ToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.生管ToolStripMenuItem.Text = "生管"
        '
        '出货金额及入库金额ToolStripMenuItem
        '
        Me.出货金额及入库金额ToolStripMenuItem.Enabled = False
        Me.出货金额及入库金额ToolStripMenuItem.Name = "出货金额及入库金额ToolStripMenuItem"
        Me.出货金额及入库金额ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.出货金额及入库金额ToolStripMenuItem.Text = "出货金额及入库金额"
        '
        '模拟展料报表ToolStripMenuItem
        '
        Me.模拟展料报表ToolStripMenuItem.Name = "模拟展料报表ToolStripMenuItem"
        Me.模拟展料报表ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.模拟展料报表ToolStripMenuItem.Text = "模拟展料报表-特定料件"
        '
        '模拟展料报表全部料件ToolStripMenuItem
        '
        Me.模拟展料报表全部料件ToolStripMenuItem.Name = "模拟展料报表全部料件ToolStripMenuItem"
        Me.模拟展料报表全部料件ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.模拟展料报表全部料件ToolStripMenuItem.Text = "模拟展料报表-全部料件"
        '
        '未结案工单明细ToolStripMenuItem
        '
        Me.未结案工单明细ToolStripMenuItem.Name = "未结案工单明细ToolStripMenuItem"
        Me.未结案工单明细ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.未结案工单明细ToolStripMenuItem.Text = "未结案工单明细"
        '
        '主材料损耗率报表ToolStripMenuItem
        '
        Me.主材料损耗率报表ToolStripMenuItem.Name = "主材料损耗率报表ToolStripMenuItem"
        Me.主材料损耗率报表ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.主材料损耗率报表ToolStripMenuItem.Text = "主材料损耗率报表"
        '
        '不良品库存与返工工单匹配表ToolStripMenuItem
        '
        Me.不良品库存与返工工单匹配表ToolStripMenuItem.Enabled = False
        Me.不良品库存与返工工单匹配表ToolStripMenuItem.Name = "不良品库存与返工工单匹配表ToolStripMenuItem"
        Me.不良品库存与返工工单匹配表ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.不良品库存与返工工单匹配表ToolStripMenuItem.Text = "不良品库存与返工工单匹配表"
        '
        '请购单汇入ToolStripMenuItem
        '
        Me.请购单汇入ToolStripMenuItem.Name = "请购单汇入ToolStripMenuItem"
        Me.请购单汇入ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.请购单汇入ToolStripMenuItem.Text = "请购单汇入"
        '
        '资材ToolStripMenuItem
        '
        Me.资材ToolStripMenuItem.Name = "资材ToolStripMenuItem"
        Me.资材ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.资材ToolStripMenuItem.Text = "资材仓异动报表"
        '
        '单阶材料用途表ToolStripMenuItem
        '
        Me.单阶材料用途表ToolStripMenuItem.Name = "单阶材料用途表ToolStripMenuItem"
        Me.单阶材料用途表ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.单阶材料用途表ToolStripMenuItem.Text = "单阶材料用途表"
        '
        '材料用途查询ToolStripMenuItem
        '
        Me.材料用途查询ToolStripMenuItem.Name = "材料用途查询ToolStripMenuItem"
        Me.材料用途查询ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.材料用途查询ToolStripMenuItem.Text = "材料用途查询"
        '
        '杂发单ToolStripMenuItem
        '
        Me.杂发单ToolStripMenuItem.Name = "杂发单ToolStripMenuItem"
        Me.杂发单ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.杂发单ToolStripMenuItem.Text = "杂发单汇入"
        '
        '排程ToolStripMenuItem
        '
        Me.排程ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.排程汇入ToolStripMenuItem, Me.胶合周排程用量表ToolStripMenuItem})
        Me.排程ToolStripMenuItem.Enabled = False
        Me.排程ToolStripMenuItem.Name = "排程ToolStripMenuItem"
        Me.排程ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.排程ToolStripMenuItem.Text = "排程"
        '
        '排程汇入ToolStripMenuItem
        '
        Me.排程汇入ToolStripMenuItem.Name = "排程汇入ToolStripMenuItem"
        Me.排程汇入ToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.排程汇入ToolStripMenuItem.Text = "排程汇入"
        '
        '胶合周排程用量表ToolStripMenuItem
        '
        Me.胶合周排程用量表ToolStripMenuItem.Name = "胶合周排程用量表ToolStripMenuItem"
        Me.胶合周排程用量表ToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.胶合周排程用量表ToolStripMenuItem.Text = "胶合周排程用量表"
        '
        '材料用途报表ToolStripMenuItem
        '
        Me.材料用途报表ToolStripMenuItem.Name = "材料用途报表ToolStripMenuItem"
        Me.材料用途报表ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.材料用途报表ToolStripMenuItem.Text = "临时MRP报表"
        '
        'ShipmentManagementToolStripMenuItem
        '
        Me.ShipmentManagementToolStripMenuItem.Enabled = False
        Me.ShipmentManagementToolStripMenuItem.Name = "ShipmentManagementToolStripMenuItem"
        Me.ShipmentManagementToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.ShipmentManagementToolStripMenuItem.Text = "shipment management"
        '
        '入库计划汇入ToolStripMenuItem
        '
        Me.入库计划汇入ToolStripMenuItem.Name = "入库计划汇入ToolStripMenuItem"
        Me.入库计划汇入ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.入库计划汇入ToolStripMenuItem.Text = "入库计划汇入"
        '
        'ERP安全存量汇入ToolStripMenuItem
        '
        Me.ERP安全存量汇入ToolStripMenuItem.Name = "ERP安全存量汇入ToolStripMenuItem"
        Me.ERP安全存量汇入ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.ERP安全存量汇入ToolStripMenuItem.Text = "ERP安全存量汇入"
        '
        'DemandAndScheduleToolStripMenuItem
        '
        Me.DemandAndScheduleToolStripMenuItem.Enabled = False
        Me.DemandAndScheduleToolStripMenuItem.Name = "DemandAndScheduleToolStripMenuItem"
        Me.DemandAndScheduleToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.DemandAndScheduleToolStripMenuItem.Text = "Demand and schedule"
        '
        'MPL接单记录ToolStripMenuItem
        '
        Me.MPL接单记录ToolStripMenuItem.Name = "MPL接单记录ToolStripMenuItem"
        Me.MPL接单记录ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.MPL接单记录ToolStripMenuItem.Text = "MPL接单记录"
        '
        '原材料进料计划达成汇总报表ToolStripMenuItem
        '
        Me.原材料进料计划达成汇总报表ToolStripMenuItem.Name = "原材料进料计划达成汇总报表ToolStripMenuItem"
        Me.原材料进料计划达成汇总报表ToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.原材料进料计划达成汇总报表ToolStripMenuItem.Text = "原材料进料计划达成汇总报表"
        '
        '采购ToolStripMenuItem
        '
        Me.采购ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.客制询价次数报表ToolStripMenuItem, Me.客制采购年度报表ToolStripMenuItem, Me.客制询价明细报表ToolStripMenuItem, Me.付款期报表ToolStripMenuItem, Me.客制采购月度报表ToolStripMenuItem, Me.采购成本指标ToolStripMenuItem, Me.验退仓退明细表ToolStripMenuItem, Me.采购入库金额单价采购量统计表ToolStripMenuItem})
        Me.采购ToolStripMenuItem.Name = "采购ToolStripMenuItem"
        Me.采购ToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.采购ToolStripMenuItem.Text = "采购"
        '
        '客制询价次数报表ToolStripMenuItem
        '
        Me.客制询价次数报表ToolStripMenuItem.Name = "客制询价次数报表ToolStripMenuItem"
        Me.客制询价次数报表ToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.客制询价次数报表ToolStripMenuItem.Text = "客制询价次数报表"
        '
        '客制采购年度报表ToolStripMenuItem
        '
        Me.客制采购年度报表ToolStripMenuItem.Name = "客制采购年度报表ToolStripMenuItem"
        Me.客制采购年度报表ToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.客制采购年度报表ToolStripMenuItem.Text = "客制采购年度报表"
        '
        '客制询价明细报表ToolStripMenuItem
        '
        Me.客制询价明细报表ToolStripMenuItem.Name = "客制询价明细报表ToolStripMenuItem"
        Me.客制询价明细报表ToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.客制询价明细报表ToolStripMenuItem.Text = "客制询价明细报表"
        '
        '付款期报表ToolStripMenuItem
        '
        Me.付款期报表ToolStripMenuItem.Name = "付款期报表ToolStripMenuItem"
        Me.付款期报表ToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.付款期报表ToolStripMenuItem.Text = "付款期报表"
        '
        '客制采购月度报表ToolStripMenuItem
        '
        Me.客制采购月度报表ToolStripMenuItem.Name = "客制采购月度报表ToolStripMenuItem"
        Me.客制采购月度报表ToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.客制采购月度报表ToolStripMenuItem.Text = "客制采购月度报表"
        '
        '采购成本指标ToolStripMenuItem
        '
        Me.采购成本指标ToolStripMenuItem.Name = "采购成本指标ToolStripMenuItem"
        Me.采购成本指标ToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.采购成本指标ToolStripMenuItem.Text = "采购成本指标"
        '
        '验退仓退明细表ToolStripMenuItem
        '
        Me.验退仓退明细表ToolStripMenuItem.Name = "验退仓退明细表ToolStripMenuItem"
        Me.验退仓退明细表ToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.验退仓退明细表ToolStripMenuItem.Text = "验退仓退明细表"
        '
        '采购入库金额单价采购量统计表ToolStripMenuItem
        '
        Me.采购入库金额单价采购量统计表ToolStripMenuItem.Name = "采购入库金额单价采购量统计表ToolStripMenuItem"
        Me.采购入库金额单价采购量统计表ToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.采购入库金额单价采购量统计表ToolStripMenuItem.Text = "采购入库金额单价采购量统计表"
        '
        '技术ToolStripMenuItem
        '
        Me.技术ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.专案报表ToolStripMenuItem, Me.专案人力输入ToolStripMenuItem, Me.专案工时报表ToolStripMenuItem, Me.RD纱料用量表ToolStripMenuItem, Me.RD人工工时月报ToolStripMenuItem, Me.Tooling完工比例报表ToolStripMenuItem})
        Me.技术ToolStripMenuItem.Name = "技术ToolStripMenuItem"
        Me.技术ToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.技术ToolStripMenuItem.Text = "技术"
        '
        '专案报表ToolStripMenuItem
        '
        Me.专案报表ToolStripMenuItem.Name = "专案报表ToolStripMenuItem"
        Me.专案报表ToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.专案报表ToolStripMenuItem.Text = "专案成本报表"
        '
        '专案人力输入ToolStripMenuItem
        '
        Me.专案人力输入ToolStripMenuItem.Name = "专案人力输入ToolStripMenuItem"
        Me.专案人力输入ToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.专案人力输入ToolStripMenuItem.Text = "专案人力输入"
        '
        '专案工时报表ToolStripMenuItem
        '
        Me.专案工时报表ToolStripMenuItem.Name = "专案工时报表ToolStripMenuItem"
        Me.专案工时报表ToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.专案工时报表ToolStripMenuItem.Text = "专案工时报表"
        '
        'RD纱料用量表ToolStripMenuItem
        '
        Me.RD纱料用量表ToolStripMenuItem.Name = "RD纱料用量表ToolStripMenuItem"
        Me.RD纱料用量表ToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.RD纱料用量表ToolStripMenuItem.Text = "RD纱料用量表"
        '
        'RD人工工时月报ToolStripMenuItem
        '
        Me.RD人工工时月报ToolStripMenuItem.Name = "RD人工工时月报ToolStripMenuItem"
        Me.RD人工工时月报ToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.RD人工工时月报ToolStripMenuItem.Text = "RD人工工时月报"
        '
        'Tooling完工比例报表ToolStripMenuItem
        '
        Me.Tooling完工比例报表ToolStripMenuItem.Name = "Tooling完工比例报表ToolStripMenuItem"
        Me.Tooling完工比例报表ToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.Tooling完工比例报表ToolStripMenuItem.Text = "Tooling完工比例报表"
        '
        '成本ToolStripMenuItem
        '
        Me.成本ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.报废报表ToolStripMenuItem, Me.客户别销售WIP库存成本ToolStripMenuItem, Me.工单用量分析表ToolStripMenuItem, Me.成本变动表ToolStripMenuItem, Me.采购及委外成本变动表ToolStripMenuItem, Me.采购委外料件杂收发明细表ToolStripMenuItem, Me.BOM表物料标准成本与实际成本明细表ToolStripMenuItem, Me.工单上阶在制成本明细表ToolStripMenuItem, Me.标准成本变动表ToolStripMenuItem, Me.标准成本明细表ToolStripMenuItem, Me.工单下阶在制成本明细表ToolStripMenuItem, Me.库龄成本分析ToolStripMenuItem, Me.标准采购单价与实际采购单价比较表ToolStripMenuItem, Me.品质报废周报金额统计表ToolStripMenuItem, Me.部门杂收发表ToolStripMenuItem, Me.成本倒扎表ToolStripMenuItem, Me.审计倒扎表ToolStripMenuItem, Me.DAC销售成本毛利资料报表ToolStripMenuItem})
        Me.成本ToolStripMenuItem.Name = "成本ToolStripMenuItem"
        Me.成本ToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.成本ToolStripMenuItem.Text = "成本"
        '
        '报废报表ToolStripMenuItem
        '
        Me.报废报表ToolStripMenuItem.Name = "报废报表ToolStripMenuItem"
        Me.报废报表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.报废报表ToolStripMenuItem.Text = "报废报表"
        '
        '客户别销售WIP库存成本ToolStripMenuItem
        '
        Me.客户别销售WIP库存成本ToolStripMenuItem.Name = "客户别销售WIP库存成本ToolStripMenuItem"
        Me.客户别销售WIP库存成本ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.客户别销售WIP库存成本ToolStripMenuItem.Text = "客户别销售/WIP库存成本"
        '
        '工单用量分析表ToolStripMenuItem
        '
        Me.工单用量分析表ToolStripMenuItem.Name = "工单用量分析表ToolStripMenuItem"
        Me.工单用量分析表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.工单用量分析表ToolStripMenuItem.Text = "工单用量分析表"
        '
        '成本变动表ToolStripMenuItem
        '
        Me.成本变动表ToolStripMenuItem.Name = "成本变动表ToolStripMenuItem"
        Me.成本变动表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.成本变动表ToolStripMenuItem.Text = "实际成本变动表"
        '
        '采购及委外成本变动表ToolStripMenuItem
        '
        Me.采购及委外成本变动表ToolStripMenuItem.Name = "采购及委外成本变动表ToolStripMenuItem"
        Me.采购及委外成本变动表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.采购及委外成本变动表ToolStripMenuItem.Text = "采购及委外成本变动表"
        '
        '采购委外料件杂收发明细表ToolStripMenuItem
        '
        Me.采购委外料件杂收发明细表ToolStripMenuItem.Name = "采购委外料件杂收发明细表ToolStripMenuItem"
        Me.采购委外料件杂收发明细表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.采购委外料件杂收发明细表ToolStripMenuItem.Text = "采购委外料件杂收发明细表"
        '
        'BOM表物料标准成本与实际成本明细表ToolStripMenuItem
        '
        Me.BOM表物料标准成本与实际成本明细表ToolStripMenuItem.Name = "BOM表物料标准成本与实际成本明细表ToolStripMenuItem"
        Me.BOM表物料标准成本与实际成本明细表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.BOM表物料标准成本与实际成本明细表ToolStripMenuItem.Text = "BOM表物料标准成本与实际成本明细表"
        '
        '工单上阶在制成本明细表ToolStripMenuItem
        '
        Me.工单上阶在制成本明细表ToolStripMenuItem.Name = "工单上阶在制成本明细表ToolStripMenuItem"
        Me.工单上阶在制成本明细表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.工单上阶在制成本明细表ToolStripMenuItem.Text = "工单上阶在制成本明细表"
        '
        '标准成本变动表ToolStripMenuItem
        '
        Me.标准成本变动表ToolStripMenuItem.Name = "标准成本变动表ToolStripMenuItem"
        Me.标准成本变动表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.标准成本变动表ToolStripMenuItem.Text = "标准成本变动表"
        '
        '标准成本明细表ToolStripMenuItem
        '
        Me.标准成本明细表ToolStripMenuItem.Name = "标准成本明细表ToolStripMenuItem"
        Me.标准成本明细表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.标准成本明细表ToolStripMenuItem.Text = "标准成本明细表"
        '
        '工单下阶在制成本明细表ToolStripMenuItem
        '
        Me.工单下阶在制成本明细表ToolStripMenuItem.Name = "工单下阶在制成本明细表ToolStripMenuItem"
        Me.工单下阶在制成本明细表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.工单下阶在制成本明细表ToolStripMenuItem.Text = "工单下阶在制成本明细表"
        '
        '库龄成本分析ToolStripMenuItem
        '
        Me.库龄成本分析ToolStripMenuItem.Name = "库龄成本分析ToolStripMenuItem"
        Me.库龄成本分析ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.库龄成本分析ToolStripMenuItem.Text = "库龄成本分析"
        '
        '标准采购单价与实际采购单价比较表ToolStripMenuItem
        '
        Me.标准采购单价与实际采购单价比较表ToolStripMenuItem.Name = "标准采购单价与实际采购单价比较表ToolStripMenuItem"
        Me.标准采购单价与实际采购单价比较表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.标准采购单价与实际采购单价比较表ToolStripMenuItem.Text = "标准采购单价与实际采购单价比较表"
        '
        '品质报废周报金额统计表ToolStripMenuItem
        '
        Me.品质报废周报金额统计表ToolStripMenuItem.Name = "品质报废周报金额统计表ToolStripMenuItem"
        Me.品质报废周报金额统计表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.品质报废周报金额统计表ToolStripMenuItem.Text = "品质报废周报金额统计表"
        '
        '部门杂收发表ToolStripMenuItem
        '
        Me.部门杂收发表ToolStripMenuItem.Name = "部门杂收发表ToolStripMenuItem"
        Me.部门杂收发表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.部门杂收发表ToolStripMenuItem.Text = "部门杂收发表"
        '
        '成本倒扎表ToolStripMenuItem
        '
        Me.成本倒扎表ToolStripMenuItem.Name = "成本倒扎表ToolStripMenuItem"
        Me.成本倒扎表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.成本倒扎表ToolStripMenuItem.Text = "成本倒扎表"
        '
        '审计倒扎表ToolStripMenuItem
        '
        Me.审计倒扎表ToolStripMenuItem.Name = "审计倒扎表ToolStripMenuItem"
        Me.审计倒扎表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.审计倒扎表ToolStripMenuItem.Text = "审计倒扎表"
        '
        'DAC销售成本毛利资料报表ToolStripMenuItem
        '
        Me.DAC销售成本毛利资料报表ToolStripMenuItem.Name = "DAC销售成本毛利资料报表ToolStripMenuItem"
        Me.DAC销售成本毛利资料报表ToolStripMenuItem.Size = New System.Drawing.Size(283, 22)
        Me.DAC销售成本毛利资料报表ToolStripMenuItem.Text = "DAC 销售 成本 毛利资料报表"
        '
        '核查ToolStripMenuItem
        '
        Me.核查ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.杂收与库存对照表ToolStripMenuItem, Me.ERP入库与MES移转查核ToolStripMenuItem, Me.ERP工单套数表ToolStripMenuItem})
        Me.核查ToolStripMenuItem.Name = "核查ToolStripMenuItem"
        Me.核查ToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.核查ToolStripMenuItem.Text = "核查"
        '
        '杂收与库存对照表ToolStripMenuItem
        '
        Me.杂收与库存对照表ToolStripMenuItem.Name = "杂收与库存对照表ToolStripMenuItem"
        Me.杂收与库存对照表ToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.杂收与库存对照表ToolStripMenuItem.Text = "杂收与库存对照表"
        '
        'ERP入库与MES移转查核ToolStripMenuItem
        '
        Me.ERP入库与MES移转查核ToolStripMenuItem.Name = "ERP入库与MES移转查核ToolStripMenuItem"
        Me.ERP入库与MES移转查核ToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.ERP入库与MES移转查核ToolStripMenuItem.Text = "ERP入库与MES移转查核"
        '
        'ERP工单套数表ToolStripMenuItem
        '
        Me.ERP工单套数表ToolStripMenuItem.Name = "ERP工单套数表ToolStripMenuItem"
        Me.ERP工单套数表ToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.ERP工单套数表ToolStripMenuItem.Text = "ERP工单套数表"
        '
        '销售ToolStripMenuItem
        '
        Me.销售ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HACToolStripMenuItem, Me.DAC月销售报表ToolStripMenuItem, Me.DAC最后单价ToolStripMenuItem, Me.HAC销售日报表ToolStripMenuItem, Me.HAC销售周报ToolStripMenuItem, Me.HACToolStripMenuItem1, Me.SalesCompareWithBudgetToolStripMenuItem, Me.PWC产品分析明细表ToolStripMenuItem})
        Me.销售ToolStripMenuItem.Name = "销售ToolStripMenuItem"
        Me.销售ToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.销售ToolStripMenuItem.Text = "销售"
        '
        'HACToolStripMenuItem
        '
        Me.HACToolStripMenuItem.Name = "HACToolStripMenuItem"
        Me.HACToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.HACToolStripMenuItem.Text = "HAC月销售报表"
        '
        'DAC月销售报表ToolStripMenuItem
        '
        Me.DAC月销售报表ToolStripMenuItem.Name = "DAC月销售报表ToolStripMenuItem"
        Me.DAC月销售报表ToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.DAC月销售报表ToolStripMenuItem.Text = "DAC月销售报表"
        '
        'DAC最后单价ToolStripMenuItem
        '
        Me.DAC最后单价ToolStripMenuItem.Name = "DAC最后单价ToolStripMenuItem"
        Me.DAC最后单价ToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.DAC最后单价ToolStripMenuItem.Text = "DAC最后单价"
        '
        'HAC销售日报表ToolStripMenuItem
        '
        Me.HAC销售日报表ToolStripMenuItem.Name = "HAC销售日报表ToolStripMenuItem"
        Me.HAC销售日报表ToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.HAC销售日报表ToolStripMenuItem.Text = "HAC销售日报表"
        '
        'HAC销售周报ToolStripMenuItem
        '
        Me.HAC销售周报ToolStripMenuItem.Name = "HAC销售周报ToolStripMenuItem"
        Me.HAC销售周报ToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.HAC销售周报ToolStripMenuItem.Text = "HAC销售周报"
        '
        'HACToolStripMenuItem1
        '
        Me.HACToolStripMenuItem1.Name = "HACToolStripMenuItem1"
        Me.HACToolStripMenuItem1.Size = New System.Drawing.Size(229, 22)
        Me.HACToolStripMenuItem1.Text = "销售统计报表"
        '
        'SalesCompareWithBudgetToolStripMenuItem
        '
        Me.SalesCompareWithBudgetToolStripMenuItem.Name = "SalesCompareWithBudgetToolStripMenuItem"
        Me.SalesCompareWithBudgetToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.SalesCompareWithBudgetToolStripMenuItem.Text = "Sales Compare with Budget"
        '
        'PWC产品分析明细表ToolStripMenuItem
        '
        Me.PWC产品分析明细表ToolStripMenuItem.Name = "PWC产品分析明细表ToolStripMenuItem"
        Me.PWC产品分析明细表ToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.PWC产品分析明细表ToolStripMenuItem.Text = "产品分析明细表"
        '
        '应收ToolStripMenuItem
        '
        Me.应收ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HACAR账龄报表ToolStripMenuItem, Me.DACAR账龄报表ToolStripMenuItem, Me.ACAAR账龄报表ToolStripMenuItem, Me.ToolStripMenuItem4, Me.HACAR账龄报表ToolStripMenuItem1, Me.DACAR账龄报表ToolStripMenuItem1, Me.ACA账龄报表ToolStripMenuItem, Me.BVIAR账龄报表ToolStripMenuItem, Me.DACInvoice单价分析报表ToolStripMenuItem, Me.應收帳款预测表ToolStripMenuItem})
        Me.应收ToolStripMenuItem.Name = "应收ToolStripMenuItem"
        Me.应收ToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.应收ToolStripMenuItem.Text = "应收"
        '
        'HACAR账龄报表ToolStripMenuItem
        '
        Me.HACAR账龄报表ToolStripMenuItem.Name = "HACAR账龄报表ToolStripMenuItem"
        Me.HACAR账龄报表ToolStripMenuItem.Size = New System.Drawing.Size(217, 22)
        Me.HACAR账龄报表ToolStripMenuItem.Text = "逾期HAC AR账龄报表"
        '
        'DACAR账龄报表ToolStripMenuItem
        '
        Me.DACAR账龄报表ToolStripMenuItem.Name = "DACAR账龄报表ToolStripMenuItem"
        Me.DACAR账龄报表ToolStripMenuItem.Size = New System.Drawing.Size(217, 22)
        Me.DACAR账龄报表ToolStripMenuItem.Text = "逾期DAC AR账龄报表"
        '
        'ACAAR账龄报表ToolStripMenuItem
        '
        Me.ACAAR账龄报表ToolStripMenuItem.Name = "ACAAR账龄报表ToolStripMenuItem"
        Me.ACAAR账龄报表ToolStripMenuItem.Size = New System.Drawing.Size(217, 22)
        Me.ACAAR账龄报表ToolStripMenuItem.Text = "逾期ACA AR账龄报表"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(217, 22)
        Me.ToolStripMenuItem4.Text = "逾期BVI AR账龄报表"
        '
        'HACAR账龄报表ToolStripMenuItem1
        '
        Me.HACAR账龄报表ToolStripMenuItem1.Name = "HACAR账龄报表ToolStripMenuItem1"
        Me.HACAR账龄报表ToolStripMenuItem1.Size = New System.Drawing.Size(217, 22)
        Me.HACAR账龄报表ToolStripMenuItem1.Text = "HAC AR账龄报表"
        '
        'DACAR账龄报表ToolStripMenuItem1
        '
        Me.DACAR账龄报表ToolStripMenuItem1.Name = "DACAR账龄报表ToolStripMenuItem1"
        Me.DACAR账龄报表ToolStripMenuItem1.Size = New System.Drawing.Size(217, 22)
        Me.DACAR账龄报表ToolStripMenuItem1.Text = "DAC AR账龄报表"
        '
        'ACA账龄报表ToolStripMenuItem
        '
        Me.ACA账龄报表ToolStripMenuItem.Name = "ACA账龄报表ToolStripMenuItem"
        Me.ACA账龄报表ToolStripMenuItem.Size = New System.Drawing.Size(217, 22)
        Me.ACA账龄报表ToolStripMenuItem.Text = "ACA AR账龄报表"
        '
        'BVIAR账龄报表ToolStripMenuItem
        '
        Me.BVIAR账龄报表ToolStripMenuItem.Name = "BVIAR账龄报表ToolStripMenuItem"
        Me.BVIAR账龄报表ToolStripMenuItem.Size = New System.Drawing.Size(217, 22)
        Me.BVIAR账龄报表ToolStripMenuItem.Text = "BVI AR账龄报表"
        '
        'DACInvoice单价分析报表ToolStripMenuItem
        '
        Me.DACInvoice单价分析报表ToolStripMenuItem.Name = "DACInvoice单价分析报表ToolStripMenuItem"
        Me.DACInvoice单价分析报表ToolStripMenuItem.Size = New System.Drawing.Size(217, 22)
        Me.DACInvoice单价分析报表ToolStripMenuItem.Text = "DAC Invoice 单价分析报表"
        '
        '應收帳款预测表ToolStripMenuItem
        '
        Me.應收帳款预测表ToolStripMenuItem.Enabled = False
        Me.應收帳款预测表ToolStripMenuItem.Name = "應收帳款预测表ToolStripMenuItem"
        Me.應收帳款预测表ToolStripMenuItem.Size = New System.Drawing.Size(217, 22)
        Me.應收帳款预测表ToolStripMenuItem.Text = "應收帳款预测表"
        '
        '应付ToolStripMenuItem
        '
        Me.应付ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.年度应付报表ToolStripMenuItem, Me.东莞应付帐龄表ToolStripMenuItem1})
        Me.应付ToolStripMenuItem.Name = "应付ToolStripMenuItem"
        Me.应付ToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.应付ToolStripMenuItem.Text = "应付"
        '
        '年度应付报表ToolStripMenuItem
        '
        Me.年度应付报表ToolStripMenuItem.Name = "年度应付报表ToolStripMenuItem"
        Me.年度应付报表ToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.年度应付报表ToolStripMenuItem.Text = "年度应付报表"
        '
        '东莞应付帐龄表ToolStripMenuItem1
        '
        Me.东莞应付帐龄表ToolStripMenuItem1.Name = "东莞应付帐龄表ToolStripMenuItem1"
        Me.东莞应付帐龄表ToolStripMenuItem1.Size = New System.Drawing.Size(158, 22)
        Me.东莞应付帐龄表ToolStripMenuItem1.Text = "东莞应付帐龄表"
        '
        '预算ToolStripMenuItem
        '
        Me.预算ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.销售费用统计表ToolStripMenuItem, Me.制造费用表ToolStripMenuItem, Me.研发费用表ToolStripMenuItem, Me.管理费用表ToolStripMenuItem, Me.DAC客户价格比价ToolStripMenuItem, Me.毛利分析表ToolStripMenuItem, Me.项目案预算比较表ToolStripMenuItem, Me.客户预ToolStripMenuItem, Me.部门费用表ToolStripMenuItem, Me.RollingForecastToolStripMenuItem, Me.部门费用及预算汇总表ToolStripMenuItem, Me.功能主管费用表ToolStripMenuItem, Me.DAC销售预算报表ToolStripMenuItem, Me.DACToolStripMenuItem, Me.主要物料进料需求表购料资金ToolStripMenuItem})
        Me.预算ToolStripMenuItem.Name = "预算ToolStripMenuItem"
        Me.预算ToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.预算ToolStripMenuItem.Text = "预算"
        '
        '销售费用统计表ToolStripMenuItem
        '
        Me.销售费用统计表ToolStripMenuItem.Name = "销售费用统计表ToolStripMenuItem"
        Me.销售费用统计表ToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.销售费用统计表ToolStripMenuItem.Text = "销售费用统计表"
        '
        '制造费用表ToolStripMenuItem
        '
        Me.制造费用表ToolStripMenuItem.Name = "制造费用表ToolStripMenuItem"
        Me.制造费用表ToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.制造费用表ToolStripMenuItem.Text = "制造费用表"
        '
        '研发费用表ToolStripMenuItem
        '
        Me.研发费用表ToolStripMenuItem.Name = "研发费用表ToolStripMenuItem"
        Me.研发费用表ToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.研发费用表ToolStripMenuItem.Text = "研发费用表"
        '
        '管理费用表ToolStripMenuItem
        '
        Me.管理费用表ToolStripMenuItem.Name = "管理费用表ToolStripMenuItem"
        Me.管理费用表ToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.管理费用表ToolStripMenuItem.Text = "管理费用表"
        '
        'DAC客户价格比价ToolStripMenuItem
        '
        Me.DAC客户价格比价ToolStripMenuItem.Name = "DAC客户价格比价ToolStripMenuItem"
        Me.DAC客户价格比价ToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.DAC客户价格比价ToolStripMenuItem.Text = "DAC客户价格比价"
        '
        '毛利分析表ToolStripMenuItem
        '
        Me.毛利分析表ToolStripMenuItem.Name = "毛利分析表ToolStripMenuItem"
        Me.毛利分析表ToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.毛利分析表ToolStripMenuItem.Text = "毛利分析表"
        '
        '项目案预算比较表ToolStripMenuItem
        '
        Me.项目案预算比较表ToolStripMenuItem.Name = "项目案预算比较表ToolStripMenuItem"
        Me.项目案预算比较表ToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.项目案预算比较表ToolStripMenuItem.Text = "项目案预算比较表"
        '
        '客户预ToolStripMenuItem
        '
        Me.客户预ToolStripMenuItem.Name = "客户预ToolStripMenuItem"
        Me.客户预ToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.客户预ToolStripMenuItem.Text = "客户销售预算表"
        '
        '部门费用表ToolStripMenuItem
        '
        Me.部门费用表ToolStripMenuItem.Name = "部门费用表ToolStripMenuItem"
        Me.部门费用表ToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.部门费用表ToolStripMenuItem.Text = "部门费用表"
        '
        'RollingForecastToolStripMenuItem
        '
        Me.RollingForecastToolStripMenuItem.Enabled = False
        Me.RollingForecastToolStripMenuItem.Name = "RollingForecastToolStripMenuItem"
        Me.RollingForecastToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.RollingForecastToolStripMenuItem.Text = "Rolling Forecast"
        '
        '部门费用及预算汇总表ToolStripMenuItem
        '
        Me.部门费用及预算汇总表ToolStripMenuItem.Name = "部门费用及预算汇总表ToolStripMenuItem"
        Me.部门费用及预算汇总表ToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.部门费用及预算汇总表ToolStripMenuItem.Text = "部门费用及预算汇总表"
        '
        '功能主管费用表ToolStripMenuItem
        '
        Me.功能主管费用表ToolStripMenuItem.Name = "功能主管费用表ToolStripMenuItem"
        Me.功能主管费用表ToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.功能主管费用表ToolStripMenuItem.Text = "功能主管费用表"
        '
        'DAC销售预算报表ToolStripMenuItem
        '
        Me.DAC销售预算报表ToolStripMenuItem.Name = "DAC销售预算报表ToolStripMenuItem"
        Me.DAC销售预算报表ToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.DAC销售预算报表ToolStripMenuItem.Text = "DAC销售预算报表"
        '
        'DACToolStripMenuItem
        '
        Me.DACToolStripMenuItem.Name = "DACToolStripMenuItem"
        Me.DACToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.DACToolStripMenuItem.Text = "DAC销售预算成本报表"
        '
        '主要物料进料需求表购料资金ToolStripMenuItem
        '
        Me.主要物料进料需求表购料资金ToolStripMenuItem.Name = "主要物料进料需求表购料资金ToolStripMenuItem"
        Me.主要物料进料需求表购料资金ToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.主要物料进料需求表购料资金ToolStripMenuItem.Text = "主要物料进料需求表/购料资金"
        '
        'IEToolStripMenuItem
        '
        Me.IEToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.工时变更汇入ToolStripMenuItem, Me.总工时重计ToolStripMenuItem, Me.周生产资源计划报表ToolStripMenuItem})
        Me.IEToolStripMenuItem.Name = "IEToolStripMenuItem"
        Me.IEToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.IEToolStripMenuItem.Text = "IE"
        '
        '工时变更汇入ToolStripMenuItem
        '
        Me.工时变更汇入ToolStripMenuItem.Name = "工时变更汇入ToolStripMenuItem"
        Me.工时变更汇入ToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.工时变更汇入ToolStripMenuItem.Text = "工时变更汇入"
        '
        '总工时重计ToolStripMenuItem
        '
        Me.总工时重计ToolStripMenuItem.Name = "总工时重计ToolStripMenuItem"
        Me.总工时重计ToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.总工时重计ToolStripMenuItem.Text = "总工时重计"
        '
        '周生产资源计划报表ToolStripMenuItem
        '
        Me.周生产资源计划报表ToolStripMenuItem.Name = "周生产资源计划报表ToolStripMenuItem"
        Me.周生产资源计划报表ToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.周生产资源计划报表ToolStripMenuItem.Text = "周生产资源计划报表"
        '
        'PMToolStripMenuItem
        '
        Me.PMToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.多交期汇入ToolStripMenuItem, Me.ForecastToolStripMenuItem, Me.TrainfreightSIToolStripMenuItem, Me.SeafreightSIToolStripMenuItem, Me.产品EOP时间批次更新ToolStripMenuItem, Me.VDALabel列印资料ToolStripMenuItem, Me.待结案料号明细表ToolStripMenuItem})
        Me.PMToolStripMenuItem.Name = "PMToolStripMenuItem"
        Me.PMToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.PMToolStripMenuItem.Text = "CS"
        '
        '多交期汇入ToolStripMenuItem
        '
        Me.多交期汇入ToolStripMenuItem.Enabled = False
        Me.多交期汇入ToolStripMenuItem.Name = "多交期汇入ToolStripMenuItem"
        Me.多交期汇入ToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.多交期汇入ToolStripMenuItem.Text = "多交期汇入"
        '
        'ForecastToolStripMenuItem
        '
        Me.ForecastToolStripMenuItem.Name = "ForecastToolStripMenuItem"
        Me.ForecastToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.ForecastToolStripMenuItem.Text = "Forecast交期汇入"
        '
        'TrainfreightSIToolStripMenuItem
        '
        Me.TrainfreightSIToolStripMenuItem.Name = "TrainfreightSIToolStripMenuItem"
        Me.TrainfreightSIToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.TrainfreightSIToolStripMenuItem.Text = "Trainfreight SI"
        '
        'SeafreightSIToolStripMenuItem
        '
        Me.SeafreightSIToolStripMenuItem.Name = "SeafreightSIToolStripMenuItem"
        Me.SeafreightSIToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.SeafreightSIToolStripMenuItem.Text = "Seafreight SI"
        '
        '产品EOP时间批次更新ToolStripMenuItem
        '
        Me.产品EOP时间批次更新ToolStripMenuItem.Name = "产品EOP时间批次更新ToolStripMenuItem"
        Me.产品EOP时间批次更新ToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.产品EOP时间批次更新ToolStripMenuItem.Text = "产品EOP时间批次更新"
        '
        'VDALabel列印资料ToolStripMenuItem
        '
        Me.VDALabel列印资料ToolStripMenuItem.Name = "VDALabel列印资料ToolStripMenuItem"
        Me.VDALabel列印资料ToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.VDALabel列印资料ToolStripMenuItem.Text = "VDA Label 列印资料"
        '
        '待结案料号明细表ToolStripMenuItem
        '
        Me.待结案料号明细表ToolStripMenuItem.Name = "待结案料号明细表ToolStripMenuItem"
        Me.待结案料号明细表ToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.待结案料号明细表ToolStripMenuItem.Text = "待结案料号明细表"
        '
        'MDToolStripMenuItem
        '
        Me.MDToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FinicialReportToolStripMenuItem, Me.AccountingReportsToolStripMenuItem, Me.客诉费用统计表ToolStripMenuItem, Me.空运费用统计表ToolStripMenuItem})
        Me.MDToolStripMenuItem.Name = "MDToolStripMenuItem"
        Me.MDToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.MDToolStripMenuItem.Text = "MD"
        '
        'FinicialReportToolStripMenuItem
        '
        Me.FinicialReportToolStripMenuItem.Name = "FinicialReportToolStripMenuItem"
        Me.FinicialReportToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.FinicialReportToolStripMenuItem.Text = "costing reports"
        '
        'AccountingReportsToolStripMenuItem
        '
        Me.AccountingReportsToolStripMenuItem.Name = "AccountingReportsToolStripMenuItem"
        Me.AccountingReportsToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.AccountingReportsToolStripMenuItem.Text = "accounting reports"
        '
        '客诉费用统计表ToolStripMenuItem
        '
        Me.客诉费用统计表ToolStripMenuItem.Name = "客诉费用统计表ToolStripMenuItem"
        Me.客诉费用统计表ToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.客诉费用统计表ToolStripMenuItem.Text = "客诉费用统计表"
        '
        '空运费用统计表ToolStripMenuItem
        '
        Me.空运费用统计表ToolStripMenuItem.Name = "空运费用统计表ToolStripMenuItem"
        Me.空运费用统计表ToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.空运费用统计表ToolStripMenuItem.Text = "空运费用统计表"
        '
        '总账ToolStripMenuItem
        '
        Me.总账ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ISToolStripMenuItem, Me.BSToolStripMenuItem, Me.CashFlowToolStripMenuItem, Me.CashFlowForeCastToolStripMenuItem, Me.外币余额表ToolStripMenuItem, Me.传票汇入ToolStripMenuItem, Me.每周费用汇总报表ToolStripMenuItem})
        Me.总账ToolStripMenuItem.Name = "总账ToolStripMenuItem"
        Me.总账ToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.总账ToolStripMenuItem.Text = "总账"
        '
        'ISToolStripMenuItem
        '
        Me.ISToolStripMenuItem.Name = "ISToolStripMenuItem"
        Me.ISToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ISToolStripMenuItem.Text = "IS"
        '
        'BSToolStripMenuItem
        '
        Me.BSToolStripMenuItem.Name = "BSToolStripMenuItem"
        Me.BSToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.BSToolStripMenuItem.Text = "BS"
        '
        'CashFlowToolStripMenuItem
        '
        Me.CashFlowToolStripMenuItem.Name = "CashFlowToolStripMenuItem"
        Me.CashFlowToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.CashFlowToolStripMenuItem.Text = "CashFlow"
        '
        'CashFlowForeCastToolStripMenuItem
        '
        Me.CashFlowForeCastToolStripMenuItem.Enabled = False
        Me.CashFlowForeCastToolStripMenuItem.Name = "CashFlowForeCastToolStripMenuItem"
        Me.CashFlowForeCastToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.CashFlowForeCastToolStripMenuItem.Text = "CashFlow_ForeCast"
        '
        '外币余额表ToolStripMenuItem
        '
        Me.外币余额表ToolStripMenuItem.Name = "外币余额表ToolStripMenuItem"
        Me.外币余额表ToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.外币余额表ToolStripMenuItem.Text = "外币余额表"
        '
        '传票汇入ToolStripMenuItem
        '
        Me.传票汇入ToolStripMenuItem.Name = "传票汇入ToolStripMenuItem"
        Me.传票汇入ToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.传票汇入ToolStripMenuItem.Text = "传票汇入"
        '
        '每周费用汇总报表ToolStripMenuItem
        '
        Me.每周费用汇总报表ToolStripMenuItem.Name = "每周费用汇总报表ToolStripMenuItem"
        Me.每周费用汇总报表ToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.每周费用汇总报表ToolStripMenuItem.Text = "每周费用汇总报表"
        '
        'ACAToolStripMenuItem
        '
        Me.ACAToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.运费汇入ToolStripMenuItem, Me.运费明细表ToolStripMenuItem, Me.损益表汇入ToolStripMenuItem, Me.ACAISToolStripMenuItem, Me.ToolStripMenuItem10, Me.资产负债表汇入ToolStripMenuItem, Me.ACABSToolStripMenuItem, Me.CallOff汇入ToolStripMenuItem, Me.FIFO计算ToolStripMenuItem})
        Me.ACAToolStripMenuItem.Name = "ACAToolStripMenuItem"
        Me.ACAToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.ACAToolStripMenuItem.Text = "ACA"
        '
        '运费汇入ToolStripMenuItem
        '
        Me.运费汇入ToolStripMenuItem.Name = "运费汇入ToolStripMenuItem"
        Me.运费汇入ToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.运费汇入ToolStripMenuItem.Text = "运费汇入"
        '
        '运费明细表ToolStripMenuItem
        '
        Me.运费明细表ToolStripMenuItem.Name = "运费明细表ToolStripMenuItem"
        Me.运费明细表ToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.运费明细表ToolStripMenuItem.Text = "运费分摊明细表"
        '
        '损益表汇入ToolStripMenuItem
        '
        Me.损益表汇入ToolStripMenuItem.Name = "损益表汇入ToolStripMenuItem"
        Me.损益表汇入ToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.损益表汇入ToolStripMenuItem.Text = "损益表汇入"
        '
        'ACAISToolStripMenuItem
        '
        Me.ACAISToolStripMenuItem.Name = "ACAISToolStripMenuItem"
        Me.ACAISToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.ACAISToolStripMenuItem.Text = "ACA-IS"
        '
        'ToolStripMenuItem10
        '
        Me.ToolStripMenuItem10.Name = "ToolStripMenuItem10"
        Me.ToolStripMenuItem10.Size = New System.Drawing.Size(158, 22)
        Me.ToolStripMenuItem10.Text = "ACA-IS2"
        '
        '资产负债表汇入ToolStripMenuItem
        '
        Me.资产负债表汇入ToolStripMenuItem.Name = "资产负债表汇入ToolStripMenuItem"
        Me.资产负债表汇入ToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.资产负债表汇入ToolStripMenuItem.Text = "资产负债表汇入"
        '
        'ACABSToolStripMenuItem
        '
        Me.ACABSToolStripMenuItem.Name = "ACABSToolStripMenuItem"
        Me.ACABSToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.ACABSToolStripMenuItem.Text = "ACA-BS"
        '
        'CallOff汇入ToolStripMenuItem
        '
        Me.CallOff汇入ToolStripMenuItem.Name = "CallOff汇入ToolStripMenuItem"
        Me.CallOff汇入ToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.CallOff汇入ToolStripMenuItem.Text = "Call_Off汇入"
        '
        'FIFO计算ToolStripMenuItem
        '
        Me.FIFO计算ToolStripMenuItem.Name = "FIFO计算ToolStripMenuItem"
        Me.FIFO计算ToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.FIFO计算ToolStripMenuItem.Text = "FIFO计算"
        '
        '关务ToolStripMenuItem
        '
        Me.关务ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.出口货物报关单ToolStripMenuItem, Me.进口手册报关单ToolStripMenuItem, Me.进口贸易报关单ToolStripMenuItem})
        Me.关务ToolStripMenuItem.Name = "关务ToolStripMenuItem"
        Me.关务ToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.关务ToolStripMenuItem.Text = "关务"
        '
        '出口货物报关单ToolStripMenuItem
        '
        Me.出口货物报关单ToolStripMenuItem.Name = "出口货物报关单ToolStripMenuItem"
        Me.出口货物报关单ToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.出口货物报关单ToolStripMenuItem.Text = "出口货物报关单"
        '
        '进口手册报关单ToolStripMenuItem
        '
        Me.进口手册报关单ToolStripMenuItem.Name = "进口手册报关单ToolStripMenuItem"
        Me.进口手册报关单ToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.进口手册报关单ToolStripMenuItem.Text = "进口手册报关单"
        '
        '进口贸易报关单ToolStripMenuItem
        '
        Me.进口贸易报关单ToolStripMenuItem.Name = "进口贸易报关单ToolStripMenuItem"
        Me.进口贸易报关单ToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.进口贸易报关单ToolStripMenuItem.Text = "进口贸易报关单"
        '
        '工务ToolStripMenuItem
        '
        Me.工务ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.关键零部件报表ToolStripMenuItem})
        Me.工务ToolStripMenuItem.Name = "工务ToolStripMenuItem"
        Me.工务ToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.工务ToolStripMenuItem.Text = "工务"
        '
        '关键零部件报表ToolStripMenuItem
        '
        Me.关键零部件报表ToolStripMenuItem.Name = "关键零部件报表ToolStripMenuItem"
        Me.关键零部件报表ToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.关键零部件报表ToolStripMenuItem.Text = "关键零部件报表"
        '
        'HACToolStripMenuItem2
        '
        Me.HACToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.汇入VACARToolStripMenuItem})
        Me.HACToolStripMenuItem2.Name = "HACToolStripMenuItem2"
        Me.HACToolStripMenuItem2.Size = New System.Drawing.Size(99, 22)
        Me.HACToolStripMenuItem2.Text = "HAC"
        '
        '汇入VACARToolStripMenuItem
        '
        Me.汇入VACARToolStripMenuItem.Name = "汇入VACARToolStripMenuItem"
        Me.汇入VACARToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.汇入VACARToolStripMenuItem.Text = "汇入VAC AR"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.产ToolStripMenuItem, Me.MES型号站别与ERP料号对应表ToolStripMenuItem, Me.MES与ERP数量比对表ToolStripMenuItem, Me.顾客PN检查报表ToolStripMenuItem})
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(103, 20)
        Me.ToolStripMenuItem3.Text = "MES与ERP结合"
        '
        '产ToolStripMenuItem
        '
        Me.产ToolStripMenuItem.Name = "产ToolStripMenuItem"
        Me.产ToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.产ToolStripMenuItem.Text = "产出返工工单"
        '
        'MES型号站别与ERP料号对应表ToolStripMenuItem
        '
        Me.MES型号站别与ERP料号对应表ToolStripMenuItem.Name = "MES型号站别与ERP料号对应表ToolStripMenuItem"
        Me.MES型号站别与ERP料号对应表ToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.MES型号站别与ERP料号对应表ToolStripMenuItem.Text = "MES型号站别与ERP料号对应表"
        '
        'MES与ERP数量比对表ToolStripMenuItem
        '
        Me.MES与ERP数量比对表ToolStripMenuItem.Name = "MES与ERP数量比对表ToolStripMenuItem"
        Me.MES与ERP数量比对表ToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.MES与ERP数量比对表ToolStripMenuItem.Text = "MES与ERP裁纱工单数量对比"
        '
        '顾客PN检查报表ToolStripMenuItem
        '
        Me.顾客PN检查报表ToolStripMenuItem.Name = "顾客PN检查报表ToolStripMenuItem"
        Me.顾客PN检查报表ToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.顾客PN检查报表ToolStripMenuItem.Text = "顾客P/N检查报表"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MES连线测试ToolStripMenuItem, Me.ERP连线测试ToolStripMenuItem, Me.ToolStripMenuItem8, Me.ToolStripMenuItem9, Me.版本资讯ToolStripMenuItem, Me.搬家ToolStripMenuItem, Me.TESTToolStripMenuItem, Me.计算机ToolStripMenuItem, Me.TEST2ToolStripMenuItem, Me.InventoryCountToolStripMenuItem})
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(67, 20)
        Me.ToolStripMenuItem2.Text = "系统调试"
        '
        'MES连线测试ToolStripMenuItem
        '
        Me.MES连线测试ToolStripMenuItem.Name = "MES连线测试ToolStripMenuItem"
        Me.MES连线测试ToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.MES连线测试ToolStripMenuItem.Text = "MES连线测试"
        '
        'ERP连线测试ToolStripMenuItem
        '
        Me.ERP连线测试ToolStripMenuItem.Name = "ERP连线测试ToolStripMenuItem"
        Me.ERP连线测试ToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.ERP连线测试ToolStripMenuItem.Text = "ERP连线测试"
        '
        'ToolStripMenuItem8
        '
        Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
        Me.ToolStripMenuItem8.Size = New System.Drawing.Size(162, 22)
        Me.ToolStripMenuItem8.Text = "Excel测试"
        '
        'ToolStripMenuItem9
        '
        Me.ToolStripMenuItem9.Name = "ToolStripMenuItem9"
        Me.ToolStripMenuItem9.Size = New System.Drawing.Size(162, 22)
        Me.ToolStripMenuItem9.Text = "PowerPoint测试"
        '
        '版本资讯ToolStripMenuItem
        '
        Me.版本资讯ToolStripMenuItem.Name = "版本资讯ToolStripMenuItem"
        Me.版本资讯ToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.版本资讯ToolStripMenuItem.Text = "版本资讯"
        '
        '搬家ToolStripMenuItem
        '
        Me.搬家ToolStripMenuItem.Enabled = False
        Me.搬家ToolStripMenuItem.Name = "搬家ToolStripMenuItem"
        Me.搬家ToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.搬家ToolStripMenuItem.Text = "搬家"
        '
        'TESTToolStripMenuItem
        '
        Me.TESTToolStripMenuItem.Name = "TESTToolStripMenuItem"
        Me.TESTToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.TESTToolStripMenuItem.Text = "TEST"
        '
        '计算机ToolStripMenuItem
        '
        Me.计算机ToolStripMenuItem.Name = "计算机ToolStripMenuItem"
        Me.计算机ToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.计算机ToolStripMenuItem.Text = "计算机"
        '
        'TEST2ToolStripMenuItem
        '
        Me.TEST2ToolStripMenuItem.Name = "TEST2ToolStripMenuItem"
        Me.TEST2ToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.TEST2ToolStripMenuItem.Text = "TEST2"
        '
        'InventoryCountToolStripMenuItem
        '
        Me.InventoryCountToolStripMenuItem.Name = "InventoryCountToolStripMenuItem"
        Me.InventoryCountToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.InventoryCountToolStripMenuItem.Text = "InventoryCount"
        '
        '离开系统ToolStripMenuItem
        '
        Me.离开系统ToolStripMenuItem.Name = "离开系统ToolStripMenuItem"
        Me.离开系统ToolStripMenuItem.Size = New System.Drawing.Size(67, 20)
        Me.离开系统ToolStripMenuItem.Text = "离开系统"
        '
        '成型模具使用次数ToolStripMenuItem
        '
        Me.成型模具使用次数ToolStripMenuItem.Name = "成型模具使用次数ToolStripMenuItem"
        Me.成型模具使用次数ToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.成型模具使用次数ToolStripMenuItem.Text = "成型模具使用次数"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDark
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(950, 335)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "艾可迅支援程式主画面"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ERPToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 离开系统ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 成品批次特采ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MES连线测试ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SN批次报废ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 每日盘点设置ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 出纳ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 集团资金预估表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客制工站完工报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客制订单报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ERP连线测试ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 生管ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 出货金额及入库金额ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客制返工报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 采购ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 版本资讯ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客制隔离待判报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 搬家ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客制询价次数报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 模拟展料报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客制报废报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客制采购年度报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客制询价明细报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 产ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TESTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MES型号站别与ERP料号对应表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 生管用完工报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 付款期报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 技术ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 专案报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 专案人力输入ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 东莞物料需求AP模拟ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 成本ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 报废报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客户别销售WIP库存成本ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客制采购月度报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 经过次数报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 模具AP报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 采购成本指标ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 模拟展料报表全部料件ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客制交接报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WIP报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客制盘点报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 财务用盘点报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客制报废日报表ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 未结案工单明细ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 产品静置时间表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 工单用量分析表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 核查ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 杂收与库存对照表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 销售ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HACToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DAC月销售报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 应收ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HACAR账龄报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DACAR账龄报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ACAAR账龄报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DAC最后单价ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HACAR账龄报表ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DACAR账龄报表ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ACA账龄报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ERP入库与MES移转查核ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 返修记录报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 应付ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 年度应付报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MES与ERP数量比对表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 主材料损耗率报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MES基础资料报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 计算机ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 不良品库存与返工工单匹配表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 请购单汇入ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 专案工时报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WIP分站存量报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BVIAR账龄报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MES样品进度报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HAC销售日报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 涂装WIP报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WIP库龄报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 资材ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 批号SN明细表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 成本变动表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 单阶材料用途表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 材料用途查询ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 采购及委外成本变动表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 杂发单ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 预算ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 销售费用统计表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 制造费用表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 研发费用表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 管理费用表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 排程ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 排程汇入ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 胶合周排程用量表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 材料用途报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WorkingCapitalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 采购委外料件杂收发明细表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 工时变更汇入ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DAC客户价格比价ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 毛利分析表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 项目案预算比较表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客户预ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MES报废月报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 银行存款余额调节表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ERP工单套数表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BOM表物料标准成本与实际成本明细表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 工单上阶在制成本明细表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TEST2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 标准成本变动表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 标准成本明细表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 验退仓退明细表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 胶合WIP报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 接收站库龄表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 工单下阶在制成本明细表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 成品库龄报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 库龄成本分析ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客制报废解锁报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 生管用过程缺陷报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShipmentManagementToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HAC销售周报ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DACInvoice单价分析报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 入库计划汇入ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ERP安全存量汇入ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 多交期汇入ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 标准采购单价与实际采购单价比较表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MESToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DemandAndScheduleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HACToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 东莞应付帐龄表ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FinicialReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 总账ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ISToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AccountingReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 品质报废周报金额统计表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MPL接单记录ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CashFlowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CashFlowForeCastToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客诉费用统计表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 空运费用统计表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ACAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 运费汇入ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 运费明细表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 关务ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 出口货物报关单ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalesCompareWithBudgetToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MachineDefectReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 部门费用表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 部门杂收发表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 采购入库金额单价采购量统计表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 產品直通率週報ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PWC产品分析明细表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InventoryCountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 总工时重计ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RD纱料用量表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 进口手册报关单ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 进口贸易报关单ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 外币余额表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RD人工工时月报ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RollingForecastToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 经过次数报表ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 應收帳款预测表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QC称重客制报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ForecastToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 成本倒扎表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 审计倒扎表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 样品报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem8 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem9 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 损益表汇入ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ACAISToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 资产负债表汇入ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ACABSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem10 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 工务ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 关键零部件报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SN库龄表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 部门费用及预算汇总表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 功能主管费用表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CallOff汇入ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 顾客PN检查报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DAC销售成本毛利资料报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FIFO计算ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 資金計畫表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 传票汇入ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HACToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 汇入VACARToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 資金計畫表匯入入庫計劃ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TrainfreightSIToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tooling完工比例报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SeafreightSIToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 产品EOP时间批次更新ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VDALabel列印资料ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 周生产资源计划报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 客制移站报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DAC销售预算报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DACToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 主要物料进料需求表购料资金ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 每周费用汇总报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 待结案料号明细表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 原材料进料计划达成汇总报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 成型模具使用次数ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
